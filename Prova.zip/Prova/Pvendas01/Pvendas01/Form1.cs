﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[3, 4];
            string auxiliar;
            double media = 0;
           double soma =0;
            string saida = "";
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Mes: {i + 1} é semana: {j + 1}");
                    if (!double.TryParse(auxiliar, out vendas[i, j]) || (vendas[i, j] <0))
                    {
                        MessageBox.Show("Valor invalido");
                        j--;
                    }
                    else
                    {
                        soma = vendas[i,j];
                        
                    }
                    media = soma / 4;
                    saida = $"total do mês: {i + 1} semana: {j + 1} \n {soma.ToString("N2")}";

                    if(j % 4 == 0 )
                    {
                        listBoxVendas.Items.Add($" total mes: {media}");
                    }
                        listBoxVendas.Items.Add(saida);
                    

                }
            }
           
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            
        }
    }
}
