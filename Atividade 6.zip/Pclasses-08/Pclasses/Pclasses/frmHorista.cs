﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtmatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.dataEntradaEmpesa =
                Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);
            // Mostrando valores 
            MessageBox.Show("Nome:" + objHorista.NomeEmpregado + 
                "\n" + "Matricula:" + objHorista.Matricula + 
                "\n" +"Tempo trabalhado" + objHorista.TempoTrabalhado() + 
                "\n Salario:" + objHorista.SalarioBruto().ToString("n2"));
        }
    }
}
