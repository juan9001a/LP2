﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstMensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula =
                Convert.ToInt32(txtmatricula.Text);
            objMensalista.dataEntradaEmpesa =
                Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal =
                Convert.ToDouble(txtSalario.Text);


            MessageBox.Show("Nome= " + objMensalista.NomeEmpregado +
                "\n" +
                    "Matricula= " + objMensalista.Matricula +
                    "\n" +
                    "Tempo Trabalho= " +
                    objMensalista.TempoTrabalhado() +
                    "\n" + objMensalista.SalarioBruto().ToString("N2"));
        }

        private void btnMensalistaParam_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtmatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome= " + objMensalista.NomeEmpregado +
                        "\n" +
                        "Matricula= " + objMensalista.Matricula +
                        "\n" +
                        "Tempo Trabalho= " +
                        objMensalista.TempoTrabalhado() +
                        "\n" + objMensalista.SalarioBruto().ToString("N2"));

            MessageBox.Show(Mensalista.Empresa);

            // ou messageBox.show($"Empresa": {Mensalista.Empresa}");
        }
    }
}
