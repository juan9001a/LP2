﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_18_03_2025
{
    public partial class Form1 : Form
    {

        double numero1, numero2, resultado;

        private void txtNumero1_validated(object sender, EventArgs e)
        {
           if(!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido");
                txtNumero1.Focus();
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1- numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {

            if(numero2 == 0)
            {
                MessageBox.Show("Número 2 inválido");
                txtNumero2.Focus();
            }
            else
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();

            }
          
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido");
                txtNumero2.Focus();
            }
        }
    }
}
